# 部署与初始化参考

> 通用部署流程，不绑定特定服务器。部署参数（内网 IP、AD 域控、管理员账号、模型 API Key）由
> 部署者提供，AI Agent 部署时**逐项向用户询问，不允许猜测**。详细端口表/数据流见各形态部署指南。

## 0. 项目与使用前提

本技能面向 **AI AllInOne 开源企业 AI 平台**（自托管全家桶，MIT 协议）：

- GitHub：`https://github.com/sdlyxianchao/AIAllInOne`
- Gitee：`https://gitee.com/sdxianchao/AIAllInOne`

**使用前提**：必须先部署好平台，本技能才能进行运维。若用户尚未部署：

1. 告诉用户"这是 AI AllInOne 项目的部署运维技能，需要先部署平台才能使用"，给出上面的项目地址
2. 引导用户 clone 项目或下载发布包（GitHub / Gitee Releases）
3. 按下方 §2 标准流程部署，或按 §3 的 AI Agent 部署方式协助
4. 部署完成后跑健康检查验证，再进入运维模式

## 1. 部署形态选择

| 形态 | 适用 | 编排目录 |
|---|---|---|
| Windows | 单机、公司内网（Docker Desktop + WSL2），含 AD 域控对接示例 | `windows/` |
| Linux | 单机 Linux（Docker Engine） | `linux/` |
| Docker | 纯 Docker 编排参考 | `docker/` |

## 2. 标准部署流程（以 Windows 为例）

1. **前置**：机器装 Docker Desktop（WSL2 引擎），网络能访问镜像仓库
2. **取代码**：clone 项目或拷贝部署目录
3. **配 .env**：把 `.env.example` 复制为 `.env` 并填入全部凭据（各产品密码、API Key、AD/LDAP 配置、服务器内网 IP）
4. **起编排**：
   ```bash
   cd <形态目录>
   docker compose up -d
   ```
5. **初始化**（容器起来 ≠ 平台可用，必须初始化）：
   - Keycloak：创建 realm、OIDC client、`ai-platform-admin` 角色、统一管理员
   - NewAPI：配置渠道（LiteLLM/直连）、生成应用令牌（deepchat-key / dify-key）、SSO
   - Dify：独立 compose 启动、模型供应商指向 NewAPI、SSO
   - Ghost：初始化 + 部署 Corp Portal 主题 + 导入示例内容
   - Gitea：安装 + Runner 注册 + Actions 工作流
   - 监控/日志/可观测：确认抓取目标与日志管道
6. **验证**：跑健康检查脚本 → 9 阶段全过；Admin Center 可用性测试全测通过

> 初始化细节见 `<形态>/*-deploy-guide-v2.md`（含 AD 集成、端口表、许可审查）和
> `docs/admin-manual/`（30 章管理员手册，含运维/备份/故障排查，9 语言）。

## 3. AI Agent 部署（推荐）

项目提供**部署提示词**，把部署目录和提示词交给 AI Agent（WorkBuddy 等），它就能照着部署文档逐步配置：

1. Agent 先读部署指南、核对清单、docker-compose、.env 模板、自动化脚本
2. 提示词要求 Agent **逐项向用户要参数**：内网 IP、AD 域控配置、管理员账号、模型 API Key——一项都不许猜
3. 按章节推进，能用脚本用脚本；某步失败先查日志找原因再改
4. 最后端到端验证：SSO 登录、真实对话、监控、备份恢复，逐项报告结果

### 3.1 部署提示词（Windows 示例，可整段复制给 Agent）

````text
你是企业内网 AI 平台的部署工程师。请根据本目录下的《windows-deploy-guide-v2.html》部署指南、windows-checklist.html 进度清单、docker-compose.yml 与 .env.example 配置，在当前这台 Windows 机器上完整部署并验证这套「AI AllInOne」平台。全程用中文与我沟通。

## 第一步：收集必要参数（逐项问我，不要跳过、不要擅自猜测）
开始前向我收集：1) 对外服务的内网 IP；2) Skill 市场主机名（域名，用于替换 mcp-gateway/skills/skill-market/config.json 与 SKILL.md 里的 <市场主机名>，并在 hosts/DNS 里解析）；3) 身份源（接 AD 域控则要域名/域控 IP/LDAP base DN/bind DN/bind 密码/sAMAccountName，或接其他 IdP 的配置，不接则确认）；4) 统一管理员账号密码；5) 大模型 API Key（DeepSeek/OpenAI/Claude 等）；6) 按需询问告警 webhook、HTTPS、备份保留策略。

## 第二步：生成本地进度文件
基于 windows-checklist.html 的内容，在本目录生成「部署进度-<日期>.md」，所有条目复制为未完成（- [ ]）。每完成一项、每解决一个问题就更新它并简要汇报。

## 第三步：按部署指南逐步执行
精读《windows-deploy-guide-v2.html》——这是本次部署唯一的权威指南，严格按它的第 1~13 章顺序执行（不要用 windows-checklist.html 或任何旧文档替代），特别注意各章「⚠️ 关键坑」。优先用 scripts/ 下的自动化脚本（bootstrap.ps1、ghost-setup.ps1、ghost-theme-setup.ps1、ghost-content-import.ps1、keycloak-realm-init.ps1、backup.ps1、restore.ps1 等），能自动化的不要手工点 UI。其中 Ghost 门户（6.5 章）必须：①部署项目自带的 Corp Portal 主题，跑 scripts\ghost-theme-setup.ps1 自动装好并激活，不要停留在官方默认主题；②导入示例内容：先问用户「门户及各产品的对外发布地址（内网 IP 或域名，如 192.168.1.10 或 portal.company.com）」——用它替换 seed 里的 <服务器IP> 占位符（文章正文里的 NewAPI / MCP / Dify 等访问地址也一并替换，注意别把 host.docker.internal 这类容器内固定地址改掉）；再问用户「门户示例内容用什么语言」，中文则直接跑 scripts\ghost-content-import.ps1 -ServerAddr "发布地址" 导入；选其他语言时，先把 ghost-content-seed/content.json 里的 title / html / plaintext / custom_excerpt 字段翻译成目标语言（保留 <服务器IP> 占位符和所有 URL 结构不动），再导入。

## 第四步：反复测试解决
出错先查日志（docker logs、健康端点、配置）定位根因再修，不要盲目重试；需要管理员权限或我手动确认时，明确告诉我「做什么、为什么」；解决后回写进度文件并简要汇报。

## 第五步：全流程验证
全部完成后做端到端测试：容器全 Up、Keycloak SSO 登录、经 NewAPI/LiteLLM 发真实对话验证 PII 脱敏、身份源登录、监控/日志/告警、备份恢复。最后逐项汇总 ✅/❌ 结果，失败项给根因和建议。
````

## 4. 部署后核对

- 核心容器全部 Up：Keycloak / NewAPI / LiteLLM / Ghost / Gitea / Update Server / Admin Center / MCP Gateway / 监控全家桶
- 用内网 IP 访问（不要用 127.0.0.1——OIDC redirect_uri 会报 `invalid_grant`）
- `*-checklist.html` 可作部署进度核对（浏览器勾选、自动保存）

## 5. 升级流程

1. 先备份（`scripts/backup.ps1`）
2. 更新代码/拉新镜像：`git pull`（或替换部署目录）→ `docker compose pull`
3. 重建受影响服务：`docker compose up -d`
4. 健康检查验证（`health-check.ps1` / Admin Center 可用性测试）
5. 升级后检查管理门户（Admin Center）功能完整性

## 6. 发布新版本（维护者）

```powershell
# 项目根目录
.\publish.ps1 -Gitee -CommitMessage "<说明>" -Version "vX.Y" -ReleaseNotes "<发布说明>"
```

- 自动同步 windows → windows-github（脱敏密码）、构建发布目录、推 GitHub（main）+ Gitee（master）、打 tag
- 不带 `-Version` 不更新版本号
- GitHub 推送依赖网络/代理；失败时用 PowerShell 环境补推（Bash 非交互取不到凭据）

## 7. 多语言文档

- README / AI-AGENT-OPS / 部署指南 / 管理员手册均支持 9 语言（zh/zh-TW/en/fr/es/pt/ja/ko/ar）
- 管理员手册在 `docs/admin-manual/`（英文主版）+ `docs/i18n/admin-manual-*`（翻译版）
